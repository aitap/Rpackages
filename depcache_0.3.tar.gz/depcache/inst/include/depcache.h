#include <R.h>
#include <Rinternals.h>
#include <R_ext/Rdynload.h>

enum { DEPCACHE_ABI_VERSION = 1 };

typedef void (*depcache_check_abi_f)(int);
typedef void (*depcache_serialize_f)(SEXP, void (*)(void*, const void*, int), void *);

static R_INLINE void depcache_check_abi(void) {
	((depcache_check_abi_f)R_GetCCallable("depcache", "check_abi"))(DEPCACHE_ABI_VERSION);
}

static R_INLINE void depcache_serialize(SEXP s, void (*outfn)(void*, const void*, int), void *context) {
	((depcache_serialize_f)R_GetCCallable("depcache", "serialize"))(s, outfn, context);
}
