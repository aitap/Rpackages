library(depcache)

data(cars) # creates the variable in the namespace
speed <- 1 # overlaps with the NSE variable in the call
expr <- quote(lm(dist ~ speed, cars))
frame <- environment()

getdep <- function(x, envir)
	mget(sort(unique(x)), envir = envir, inherits = TRUE)

stopifnot(
	all.equal(
		depcache:::dependencies(expr, frame, depcache.options(local.only = TRUE)),
		# "speed" exists and so is picked up
		getdep(c('speed', 'cars'), frame)
	),
	all.equal(
		depcache:::dependencies(expr, frame, depcache.options(local.only = FALSE)),
		# "lm" additionally picked up
		# "dist" is a function from stats and so is picked up too
		getdep(c('speed', 'cars', 'lm', 'dist', '~'), frame)
	),
	all.equal(
		depcache:::dependencies(
			expr, frame,
			depcache.options(skip = c('speed', 'dist'), local.only = FALSE)
		),
		# explicitly asking to skip the NSE variables
		getdep(c('cars', 'lm', '~'), frame)
	),
	all.equal(
		depcache:::dependencies(
			expr, frame,
			depcache.options(skip = 'speed', local.only = TRUE)
		),
		# avoiding both problems
		getdep(c('cars'), frame)
	),
	all.equal(
		depcache:::dependencies(
			quote(
				function(...) c(list(...), speed = speed)
			),
			frame,
			depcache.options(
				local.only = TRUE, eval.ellipsis = TRUE, trace.functions = TRUE
			)
		),
		getdep(c('speed'), frame)
	)
)

haha <- 123
expr <- quote(function(...) list(haha, ...))
stopifnot(
	all.equal(
		depcache:::dependencies(
			expr, frame,
			depcache.options(
				local.only = TRUE,
				trace.functions = TRUE,
			)
		),
		getdep('haha', frame)
	)
)
stopifnot(
	all.equal(
		depcache:::dependencies(
			expr, frame,
			depcache.options(
				local.only = TRUE,
				trace.functions = FALSE,
			)
		),
		getdep(character(0), frame)
	)
)

check_ellipsis <- function(expr, deps) {
	expr <- substitute(expr)
	frame <- parent.frame()
	cur.deps <- depcache:::dependencies(
		expr, frame, depcache.options(eval.ellipsis = TRUE)
	)
	stopifnot(all.equal(deps, cur.deps$`...`))
}

(function(...) {
	check_ellipsis(list(...), list(...))
	check_ellipsis(plot(table(rbinom(100, 5, rep(1/5, 5))), ...), list(...))
})(lwd = 2+1, ylab = 'Frequency')

