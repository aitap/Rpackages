#include <R.h>
#include <Rinternals.h>

// hash.c
SEXP hash_plain(SEXP value, SEXP sver);
SEXP hash_canonical(SEXP value);
SEXP dump(SEXP value);

// serialize.c
void hash_serialize(
	SEXP s, void (*outfn)(void*, const void*, int), void *context
);
