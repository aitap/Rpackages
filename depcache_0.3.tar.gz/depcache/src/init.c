#include "depcache.h"
#include "../inst/include/depcache.h"

static void check_abi(int version) {
	if (version != DEPCACHE_ABI_VERSION) Rf_error(
		"Compiled with depcache ABI version %d, but running with "
		"depcache ABI version %d. Please reinstall the calling package.",
		version, DEPCACHE_ABI_VERSION
	);
}

static R_CallMethodDef call_methods[] = {
	{"hash_plain", (DL_FUNC)&hash_plain, 2},
	{"hash_canonical", (DL_FUNC)&hash_canonical, 1},
	{"dump", (DL_FUNC)&dump, 1},
	{NULL, NULL, 0}
};

void R_init_depcache(DllInfo *info) {
	R_registerRoutines(info, NULL, call_methods, NULL, NULL);
	depcache_check_abi_f depcache_check_abi = check_abi; // make sure prototype matches
	R_RegisterCCallable("depcache", "check_abi", (DL_FUNC)depcache_check_abi); // then register
	depcache_serialize_f depcache_serialize = hash_serialize;
	R_RegisterCCallable("depcache", "serialize", (DL_FUNC)hash_serialize);
	R_useDynamicSymbols(info, FALSE);
	R_forceSymbols(info, TRUE);
}
