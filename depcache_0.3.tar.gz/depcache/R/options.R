.defaults <- list(
	'0.1' = list(
		dir = '.depcache',
		compress = TRUE,
		local.only = TRUE,
		format.version = 2,
		eval.ellipsis = TRUE,
		trace.functions = TRUE
	),
	'0.2' = list(
		dir = '.depcache',
		compress = TRUE,
		local.only = TRUE,
		format.version = 2,
		eval.ellipsis = TRUE,
		trace.functions = FALSE
	)
)

depcache.options <- function(
	defaults = getOption('depcache.version', '0.2'),
	skip = getOption('depcache.skip', NULL),
	dir, compress, local.only, format.version, eval.ellipsis, trace.functions
) {
	defaults <- .defaults[[match.arg(defaults, names(.defaults))]]

	.getdefault <- function(var) {
		if (!missing(var)) return(var)
		name <- deparse(substitute(var))
		getOption(paste0('depcache.', name), defaults[[name]])
	}
	dir             <- .getdefault(dir)
	compress        <- .getdefault(compress)
	local.only      <- .getdefault(local.only)
	format.version  <- .getdefault(format.version)
	eval.ellipsis   <- .getdefault(eval.ellipsis)
	trace.functions <- .getdefault(trace.functions)

	stopifnot(
		is.character(dir), length(dir) == 1L,
		is.character(skip) || is.null(skip),
		length(compress) == 1L && !is.na(compress),
		is.logical(local.only) && length(local.only) == 1L,
		format.version %in% c(2,3),
		length(eval.ellipsis) == 1L && is.logical(eval.ellipsis),
		length(trace.functions) == 1L && is.logical(trace.functions)
	)

	list(
		dir = dir, compress = compress, skip = skip,
		local.only = local.only, format.version = format.version,
		eval.ellipsis = eval.ellipsis, trace.functions = trace.functions
	)
}
