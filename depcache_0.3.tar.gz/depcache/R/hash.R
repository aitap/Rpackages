# Hash arbitrary R values by serializing them and calculating a hash
# of the XDR representation. "Version" here is the format version; only
# 2 and 3 are supported.
hash_v02 <- function(value, version)
	paste(as.character(.Call(C_hash_plain, value, version)), collapse = '')

# Hash arbitrary R values by computing a "canonical" byte representation
# of them and then hashing that using 64-bit FNV1a.
hash <- function(value)
	paste(as.character(.Call(C_hash_canonical, value)), collapse = '')
