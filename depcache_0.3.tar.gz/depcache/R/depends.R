dependencies <- function(expr, frame, opts) {
	# any symbol in the expression can be a dependency
	symbols <- unname(unlist(walkCode(
		expr, makeCodeWalker(
			# handle generic calls and recurse
			call = function(call, w) {
				if (is.symbol(call[[1]]) && call[[1]] == 'function') {
					if (opts$trace.functions) {
						w$in.function <- TRUE
						lapply(call, walkCode, w = w)
					}
				} else lapply(call, walkCode, w = w)
			},
			# handle leafs of the AST
			leaf = function(l, w)
				if (
					is.symbol(l) && l != '' &&
					# ignore ellipsis inside function definitions
					# (as opposed to calls)
					(!isTRUE(w$in.function) || l != '...')
				) as.character(l)
		)
	)))

	# except the ones we're explicitly told not to hash
	# also get them in a defined order
	symbols <- sort(unique(setdiff(symbols, opts$skip)))

	# Reliable test for objects that don't exist. A value identical to a
	# freshly created environment won't be found in the environment of
	# a user expression that doesn't have access to here.
	notfound <- new.env(parent = emptyenv(), size = 0L)

	values <- mget(
		# if there's no symbols, cast NULL to character to satisfy mget;
		# don't try to get('...') as it wouldn't obtain the right value;
		setdiff(as.character(symbols), '...'),
		frame, ifnotfound = list(notfound), inherits = !opts$local.only
	)
	# we pretend missing values don't exist (some NSE likely going on)
	values <- Filter(function(v) !identical(v, notfound), values)

	# handle the ellipsis separately, by expanding it inside a
	# function call and then removing the caller
	if (opts$eval.ellipsis && '...' %in% symbols)
		values[['...']] <- eval(quote(list(...)), frame)

	values
}
